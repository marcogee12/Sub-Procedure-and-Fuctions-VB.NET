﻿' Name:         Donut Shoppe
' Purpose:      Display subtotal using a sub procedure.
'               Display Sales tax using a function.
' Programmer:   Marco Gomez on 6/25/2019

Option Explicit On
Option Strict On
Option Infer Off
Public Class Form1
    Private Sub BtnCappuc_CheckedChanged(sender As Object, e As EventArgs) Handles btnCappuc.CheckedChanged

    End Sub

    'Sub procedure does not return a value but gives a procedure for the given variable to use or pass through
    'The given variable when using a sub procedure will be in place of the sub procedures parameter variable
    Public Sub DisplaySubTotal(ByVal subTotal As Double)
        subTotal = (subTotal / 106) * 100
        lblSubtotal.Text = FormatCurrency(subTotal)
    End Sub

    'Sales tax as a function. This takes the variable being passed to it and takes it through the procedure
    'But unlike a sub procedure, a function return the value of the variable once its been through the procedure.
    Function GetTax(ByVal taxSales As Double) As Double
        taxSales = (taxSales / 106) * 6
        Return taxSales
    End Function
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Scope for variables in group boxes of donuts and coffee
        Dim Donut As Double
        Dim Coffee As Double

        'Sets prices for donuts
        If btnGlazed.Checked Then
            Donut = 1.05
        ElseIf btnSugar.Checked Then
            Donut = 1.05
        ElseIf btnChoco.Checked Then
            Donut = 1.25
        ElseIf btnFilled.Checked Then
            Donut = 1.5
        End If

        'Sets prices for coffee
        If btnNone.Checked Then
            Coffee = 0
        ElseIf btnReg.Checked Then
            Coffee = 1.5
        ElseIf btnCappuc.Checked Then
            Coffee = 2.75
        End If

        'Scope for the total and how it is calculated including sales tax
        Dim Total As Double
        Total = (Donut + Coffee) * 1.06

        'Calculate button will run the DisplaySubtotal Procedure using Total in place of 'subTotal'
        'which was used in the sub procedure.
        DisplaySubTotal(Total)

        'Gives lblTax the value of GetTax function using Total as the variable instead of taxSales
        lblTax.Text = FormatCurrency(GetTax(Total))

        'Prints total
        lblTotal.Text = FormatCurrency(Total)

    End Sub

    'Sets the calculate button as a default.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnCalc
    End Sub
End Class
