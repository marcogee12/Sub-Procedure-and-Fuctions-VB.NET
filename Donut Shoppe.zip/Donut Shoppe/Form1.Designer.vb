﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnSugar = New System.Windows.Forms.RadioButton()
        Me.btnChoco = New System.Windows.Forms.RadioButton()
        Me.btnFilled = New System.Windows.Forms.RadioButton()
        Me.btnGlazed = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblSubtotal = New System.Windows.Forms.TextBox()
        Me.lblTax = New System.Windows.Forms.TextBox()
        Me.lblTotal = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnCappuc = New System.Windows.Forms.RadioButton()
        Me.btnReg = New System.Windows.Forms.RadioButton()
        Me.btnNone = New System.Windows.Forms.RadioButton()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(519, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Our Donut and Coffee are the Best in Town!"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnSugar)
        Me.GroupBox1.Controls.Add(Me.btnChoco)
        Me.GroupBox1.Controls.Add(Me.btnFilled)
        Me.GroupBox1.Controls.Add(Me.btnGlazed)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.GroupBox1.Location = New System.Drawing.Point(38, 41)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(190, 264)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Donut Choices"
        '
        'btnSugar
        '
        Me.btnSugar.AutoSize = True
        Me.btnSugar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnSugar.Location = New System.Drawing.Point(15, 96)
        Me.btnSugar.Name = "btnSugar"
        Me.btnSugar.Size = New System.Drawing.Size(131, 24)
        Me.btnSugar.TabIndex = 2
        Me.btnSugar.TabStop = True
        Me.btnSugar.Text = "Sugar ($1.05)"
        Me.btnSugar.UseVisualStyleBackColor = True
        '
        'btnChoco
        '
        Me.btnChoco.AutoSize = True
        Me.btnChoco.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnChoco.Location = New System.Drawing.Point(15, 151)
        Me.btnChoco.Name = "btnChoco"
        Me.btnChoco.Size = New System.Drawing.Size(160, 24)
        Me.btnChoco.TabIndex = 3
        Me.btnChoco.TabStop = True
        Me.btnChoco.Text = "Chocolate ($1.25)"
        Me.btnChoco.UseVisualStyleBackColor = True
        '
        'btnFilled
        '
        Me.btnFilled.AutoSize = True
        Me.btnFilled.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnFilled.Location = New System.Drawing.Point(15, 205)
        Me.btnFilled.Name = "btnFilled"
        Me.btnFilled.Size = New System.Drawing.Size(125, 24)
        Me.btnFilled.TabIndex = 4
        Me.btnFilled.TabStop = True
        Me.btnFilled.Text = "Filled ($1.50)"
        Me.btnFilled.UseVisualStyleBackColor = True
        '
        'btnGlazed
        '
        Me.btnGlazed.AutoSize = True
        Me.btnGlazed.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnGlazed.Location = New System.Drawing.Point(15, 43)
        Me.btnGlazed.Name = "btnGlazed"
        Me.btnGlazed.Size = New System.Drawing.Size(139, 24)
        Me.btnGlazed.TabIndex = 0
        Me.btnGlazed.TabStop = True
        Me.btnGlazed.Text = "Glazed ($1.05)"
        Me.btnGlazed.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblSubtotal)
        Me.GroupBox2.Controls.Add(Me.lblTax)
        Me.GroupBox2.Controls.Add(Me.lblTotal)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(287, 41)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(209, 199)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'lblSubtotal
        '
        Me.lblSubtotal.Location = New System.Drawing.Point(93, 22)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(100, 26)
        Me.lblSubtotal.TabIndex = 3
        '
        'lblTax
        '
        Me.lblTax.Location = New System.Drawing.Point(93, 82)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(100, 26)
        Me.lblTax.TabIndex = 4
        '
        'lblTotal
        '
        Me.lblTotal.Location = New System.Drawing.Point(93, 151)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 26)
        Me.lblTotal.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 151)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 20)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Total Due:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 20)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Sales Tax:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Subtotal:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnCappuc)
        Me.GroupBox3.Controls.Add(Me.btnReg)
        Me.GroupBox3.Controls.Add(Me.btnNone)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.GroupBox3.Location = New System.Drawing.Point(38, 311)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(190, 166)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Coffee Choices"
        '
        'btnCappuc
        '
        Me.btnCappuc.AutoSize = True
        Me.btnCappuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnCappuc.Location = New System.Drawing.Point(6, 131)
        Me.btnCappuc.Name = "btnCappuc"
        Me.btnCappuc.Size = New System.Drawing.Size(172, 24)
        Me.btnCappuc.TabIndex = 2
        Me.btnCappuc.TabStop = True
        Me.btnCappuc.Text = "Cappuccino ($2.75)"
        Me.btnCappuc.UseVisualStyleBackColor = True
        '
        'btnReg
        '
        Me.btnReg.AutoSize = True
        Me.btnReg.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnReg.Location = New System.Drawing.Point(6, 78)
        Me.btnReg.Name = "btnReg"
        Me.btnReg.Size = New System.Drawing.Size(144, 24)
        Me.btnReg.TabIndex = 1
        Me.btnReg.TabStop = True
        Me.btnReg.Text = "Regular ($1.50)"
        Me.btnReg.UseVisualStyleBackColor = True
        '
        'btnNone
        '
        Me.btnNone.AutoSize = True
        Me.btnNone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnNone.Location = New System.Drawing.Point(6, 29)
        Me.btnNone.Name = "btnNone"
        Me.btnNone.Size = New System.Drawing.Size(72, 24)
        Me.btnNone.TabIndex = 0
        Me.btnNone.TabStop = True
        Me.btnNone.Text = "None"
        Me.btnNone.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnCalc.Location = New System.Drawing.Point(338, 311)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(110, 34)
        Me.btnCalc.TabIndex = 4
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnExit.Location = New System.Drawing.Point(338, 379)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(110, 34)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(545, 494)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Donut Shoppe"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnSugar As RadioButton
    Friend WithEvents btnChoco As RadioButton
    Friend WithEvents btnFilled As RadioButton
    Friend WithEvents btnGlazed As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblSubtotal As TextBox
    Friend WithEvents lblTax As TextBox
    Friend WithEvents lblTotal As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnCappuc As RadioButton
    Friend WithEvents btnReg As RadioButton
    Friend WithEvents btnNone As RadioButton
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
End Class
